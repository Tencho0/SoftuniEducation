﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-CBM43GM\\MSSQLSERVER01;Database=BookShop;Integrated Security=True;";
    }
}
