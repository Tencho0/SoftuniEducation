﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-CBM43GM\MSSQLSERVER01;Database=MusicHub;Trusted_Connection=True";
    }
}
