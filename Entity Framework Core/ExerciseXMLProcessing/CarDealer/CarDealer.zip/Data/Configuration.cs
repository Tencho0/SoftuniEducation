﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-CBM43GM\MSSQLSERVER01;Database=CarDealer;Integrated Security=True;Encrypt=False";
    }
}
