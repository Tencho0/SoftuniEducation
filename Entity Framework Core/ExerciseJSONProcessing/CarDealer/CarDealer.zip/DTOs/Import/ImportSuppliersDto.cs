﻿namespace CarDealer.DTOs.Import
{
    public class ImportSuppliersDto
    {
        public string Name { get; set; } = null!;
        public bool isImporter { get; set; }
    }
}
