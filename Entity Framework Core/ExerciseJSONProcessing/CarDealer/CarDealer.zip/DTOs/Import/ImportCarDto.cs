﻿namespace CarDealer.DTOs.Import
{
    public class ImportCarDto
    {
    }
}
