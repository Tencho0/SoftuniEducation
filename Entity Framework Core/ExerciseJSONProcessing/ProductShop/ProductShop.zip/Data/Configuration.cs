﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-CBM43GM\MSSQLSERVER01;Database=ProductShop;Integrated Security=True;Encrypt=False;";
    }
}
