﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-CBM43GM\MSSQLSERVER01;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
