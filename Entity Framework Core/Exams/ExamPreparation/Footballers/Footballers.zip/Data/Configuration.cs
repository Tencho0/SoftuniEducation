﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-CBM43GM\MSSQLSERVER01;Database=FootballersExam;Trusted_Connection=True";
    }
}
