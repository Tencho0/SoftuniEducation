﻿namespace Footballers.Data.Models.Enums
{
    public enum PositionType
    {
        Goalkeeper = 0,
        Defender,
        Midfielder,
        Forward
    }
}