﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-CBM43GM\MSSQLSERVER01;Database=Artillery;Integrated Security=True;Encrypt=False";
    }
}
