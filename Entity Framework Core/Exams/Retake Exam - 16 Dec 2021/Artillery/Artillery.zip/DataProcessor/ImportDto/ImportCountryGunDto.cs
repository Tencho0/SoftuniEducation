﻿namespace Artillery.DataProcessor.ImportDto
{
    public class ImportCountryGunDto
    {
        public int Id { get; set; }
    }
}
