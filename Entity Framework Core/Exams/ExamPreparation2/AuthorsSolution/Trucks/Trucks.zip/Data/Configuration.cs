﻿namespace Trucks.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=Viktor\SQLEXPRESS;Database=Trucks;Trusted_Connection=True";
    }
}