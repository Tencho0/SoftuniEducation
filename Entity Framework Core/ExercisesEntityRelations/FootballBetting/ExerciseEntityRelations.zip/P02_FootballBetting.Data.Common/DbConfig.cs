﻿namespace P02_FootballBetting.Data.Common
{
    public static class DbConfig
    {
        public const string ConnectionString =
            @"Server=DESKTOP-CBM43GM\MSSQLSERVER01;Database=Bet365;Integrated Security=True;Encrypt=False;";
    }
}