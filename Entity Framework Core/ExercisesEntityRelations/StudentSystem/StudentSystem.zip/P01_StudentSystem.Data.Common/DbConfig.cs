﻿namespace P01_StudentSystem.Data.Common;

public static class DbConfig
{
    public const string ConnectionString =
        @"Server=DESKTOP-CBM43GM\MSSQLSERVER01;Database=StudentSystem;Integrated Security=True;Encrypt=False;";
}