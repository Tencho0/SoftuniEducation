﻿namespace P01_StudentSystem.Data
{
    public static class Config
    {
        public const string ConnectionString =
            @"Server=.;Database=StudentSystem;Integrated Security=True;Encrypt=False;";
    }
}