﻿namespace WarCroft.Entities.Inventory
{
    public class Satchel : Bag
    {
        public Satchel() 
            : base(20)
        {
        }
    }
}
