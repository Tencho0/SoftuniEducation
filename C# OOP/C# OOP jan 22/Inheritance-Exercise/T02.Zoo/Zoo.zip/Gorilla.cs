﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T02.Zoo
{
    public class Gorilla : Mammal
    {
        public Gorilla(string name)
             : base(name)
        {

        }
    }
}
