﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    public interface IBird
    {
        public double WingSize { get; set; }
    }
}
