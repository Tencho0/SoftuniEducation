﻿namespace FoodShortage
{
    public interface IBuyer
    {
        public int Food { get; set; }
        int BuyFood();
    }
}
