﻿namespace FoodShortage
{
    public interface IBirthdate
    {
        string Birthdate { get; set; }
    }
}
