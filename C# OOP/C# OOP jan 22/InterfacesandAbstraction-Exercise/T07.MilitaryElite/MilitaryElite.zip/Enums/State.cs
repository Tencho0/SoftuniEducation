﻿namespace MilitaryElite
{
    public enum State
    {
        inProgress = 1,
        Finished = 2
    }
}
