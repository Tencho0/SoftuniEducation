﻿namespace MilitaryElite
{
    public interface IEngine
    {
        void Run();
    }
}
