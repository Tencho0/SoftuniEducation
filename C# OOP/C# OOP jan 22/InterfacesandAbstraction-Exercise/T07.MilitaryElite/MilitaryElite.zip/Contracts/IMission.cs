﻿namespace MilitaryElite
{
    public interface IMission
    {
        string CodeName { get; set; }
        State State { get; set; }

    }
}
