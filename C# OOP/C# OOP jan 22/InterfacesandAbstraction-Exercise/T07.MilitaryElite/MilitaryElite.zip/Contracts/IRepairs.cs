﻿namespace MilitaryElite
{
    public interface IRepairs
    {
        string Name { get; set; }
        int WorkingHours { get; set; }

    }
}
