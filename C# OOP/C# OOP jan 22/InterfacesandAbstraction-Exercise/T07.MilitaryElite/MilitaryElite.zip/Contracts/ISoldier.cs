﻿namespace MilitaryElite
{
    public interface ISoldier
    {
        int Id { get; set; }
        string FirstName { get; set; }
        string LastName { get; set; }

    }
}
