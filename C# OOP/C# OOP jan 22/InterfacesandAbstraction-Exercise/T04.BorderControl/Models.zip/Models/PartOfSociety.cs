﻿namespace T04.BorderControl.Models
{
    public class PartOfSociety
    {
        public string Id { get; set; }
    }
}
