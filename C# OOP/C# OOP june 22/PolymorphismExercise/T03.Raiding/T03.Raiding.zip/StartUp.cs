﻿namespace T03.Raiding
{
    using T03.Raiding.Core;
    public class StartUp
    {

        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
