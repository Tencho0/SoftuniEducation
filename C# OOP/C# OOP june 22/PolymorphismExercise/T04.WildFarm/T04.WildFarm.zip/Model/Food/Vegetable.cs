﻿namespace T04.WildFarm.Model.Food
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity)
            : base(quantity)
        {
        }
    }
}
