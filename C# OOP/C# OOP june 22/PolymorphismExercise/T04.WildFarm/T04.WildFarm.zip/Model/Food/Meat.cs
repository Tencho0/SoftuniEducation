﻿namespace T04.WildFarm.Model.Food
{
    public class Meat : Food
    {
        public Meat(int quantity) 
            : base(quantity)
        {
        }
    }
}
