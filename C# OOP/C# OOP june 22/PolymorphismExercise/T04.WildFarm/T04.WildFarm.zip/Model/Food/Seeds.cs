﻿namespace T04.WildFarm.Model.Food
{
    public class Seeds : Food
    {
        public Seeds(int quantity)
            : base(quantity)
        {
        }
    }
}
