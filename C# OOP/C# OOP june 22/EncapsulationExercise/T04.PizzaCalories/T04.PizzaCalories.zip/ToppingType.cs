﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T04.PizzaCalories
{
    public enum ToppingType
    {
        MEAT,
        VEGGIES,
        CHEESE,
        SAUCE,
        INVALID
    }
}
