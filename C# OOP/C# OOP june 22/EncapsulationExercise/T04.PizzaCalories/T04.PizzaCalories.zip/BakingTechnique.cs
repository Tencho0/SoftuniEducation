﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T04.PizzaCalories
{
    public enum BakingTechnique
    {
        CRISPY,
        CHEWY,
        HOMEMADE,
        INVALID
    }
}
