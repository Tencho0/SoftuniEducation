﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T05.BirthdayCelebrations.Contracts
{
    public interface IIdentifiable
    {
        public string Id { get; set; }
    }
}
