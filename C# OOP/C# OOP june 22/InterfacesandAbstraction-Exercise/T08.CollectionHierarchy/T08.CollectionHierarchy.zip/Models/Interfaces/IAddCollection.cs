﻿namespace T08.CollectionHierarchy.Models.Interfaces
{
    public interface IAddCollection<T>
    {
        int AddCollection(T item);
    }
}
