﻿namespace T07.MilitaryElite.Contracts
{
    public interface IRepairs
    {
        public string Name { get; set; }
        public int WorkedHours { get; set; }
    }
}
