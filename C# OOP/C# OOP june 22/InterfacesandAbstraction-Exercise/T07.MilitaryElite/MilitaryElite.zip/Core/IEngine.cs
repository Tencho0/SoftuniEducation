﻿namespace T07.MilitaryElite.Core
{
    public interface IEngine
    {
        void Run();
    }
}