﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T03.Telephony
{
    public interface IBrowsable
    {
        public string Browse(string URL);
    }
}
