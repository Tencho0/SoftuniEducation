﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T05.BirthdayCelebrations.Contracts
{
    public interface IBirthdable
    {
        public string Birthdate { get; set; }
    }
}
