﻿namespace T05.BirthdayCelebrations
{
    public interface IBuyer
    {
        public int BuyFood();
        public int Food { get; set; }
    }
}
